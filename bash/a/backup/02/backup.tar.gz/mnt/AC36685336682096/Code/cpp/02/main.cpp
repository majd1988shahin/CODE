#include <iostream>
#include <cmath>
#include "funcs.h"
using namespace std;
 
int main () {
   // number definition:
   /*ops();
   cout<<"ops func .......\n";
   for (int i =0;i<10;i++)cout<<"random number "<<random_(i)%10<<endl;
   cout<<"Random long "<<random_2()<<endl;*/
   /*
   int size;
   cout<<"enter array size : ";
   cin>>size;
   Array a=creat_random_array(size);
   print_array(a);*/
   //charArrayTest();
   stringTest();
   return 0;
}