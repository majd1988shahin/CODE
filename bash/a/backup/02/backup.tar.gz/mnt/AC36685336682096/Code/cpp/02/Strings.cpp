#include "funcs.h"
#include <string>
#include <iostream>
//http://www.cplusplus.com/reference/string/string/string/
void stringTest(void)
{
    std::string s="Hello";
    //s=s*3;
    std::cout<<s<<std::endl;
}

