
int ex=3;