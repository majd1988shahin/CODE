#ifndef FUNC__
#define FUNC__
#include <iostream>
#include <cstdarg>
using namespace std;
double average(int num,...);
#endif