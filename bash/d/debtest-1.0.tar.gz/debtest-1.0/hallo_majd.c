#include <stdio.h>
#include <stdlib.h>
char hello_string[] = "hello majd";
int main ()
{
	printf ("\n%s\n\n", hello_string);
	exit (EXIT_SUCCESS);
}
